NAME=$1
PROJECT=$2

rm -rf ./projects/$PROJECT
mkdir -p ./projects/$PROJECT

cp ./ca/ca.crt ./projects/$PROJECT/ca.crt
cp ./readme.pdf ./projects/$PROJECT/readme.pdf

cp ./domain/$NAME.cer ./projects/$PROJECT/$NAME.cer
cp ./domain/$NAME.crt ./projects/$PROJECT/$NAME.crt
cp ./domain/$NAME.key ./projects/$PROJECT/$NAME.key
cp ./domain/$NAME.pem ./projects/$PROJECT/$NAME.pem

currentDate=$(date +%Y%m%d_%H%M%S)
"C:\Program Files\WinRAR\Rar.exe" a -ep "./projects/$PROJECT-$currentDate.zip" "./projects/$PROJECT"
