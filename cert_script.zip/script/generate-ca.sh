######################
# Create CA certs
######################

CA=ca

# Generate private key
# openssl genrsa -des3 -out $CA.key 2048
# Generate root certificate
# openssl req -x509 -new -nodes -key $CA.key -sha256 -days 3650 -out $CA.crt
openssl req -new -x509 -extensions v3_ca -newkey rsa:2048 -sha256 -days 3650 -config ca-req.cnf -batch -nodes -out ./ca/$CA.crt -keyout ./ca/$CA.key

cat ./ca/$CA.crt ./ca/$CA.key > ./ca/$CA.pem
