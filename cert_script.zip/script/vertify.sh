read -p "input domain name:" NAME

echo "vertify domain $NAME"
openssl verify -CAfile ./ca/ca.pem -verify_hostname $NAME ./domain/$NAME.crt

echo "vertify domain test.$NAME"
openssl verify -CAfile ./ca/ca.pem -verify_hostname test.$NAME ./domain/$NAME.crt

echo "vertify domain localhost"
openssl verify -CAfile ./ca/ca.pem -verify_hostname localhost ./domain/$NAME.crt

echo "vertify domain 10.8.9.38"
openssl verify -CAfile ./ca/ca.pem -verify_ip 10.8.9.38 ./domain/$NAME.crt
