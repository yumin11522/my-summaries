# openssl req -new -x509 -newkey rsa:2048 -sha256 -days 3650 -config ca-req.cnf -out ./ca/$CA.crt -keyout ./ca/$CA.key -batch -nodes
######################
# Create CA-signed certs
######################

read -p "input domain name:" NAME

# Generate a private key
# Create a certificate-signing request
openssl req -new -newkey rsa:2048 -config domain-req.cnf -keyout ./domain/$NAME.key -out ./domain/$NAME.csr -batch -nodes

# Create a config file for the extensions
>./domain/$NAME.ext cat <<-EOF
authorityKeyIdentifier=keyid,issuer
basicConstraints=CA:FALSE
keyUsage = digitalSignature, nonRepudiation, keyEncipherment, dataEncipherment
subjectAltName = @alt_names
[alt_names]
DNS.1 = localhost # easy to test, domain name you need to modify the host
DNS.2 = $NAME # Be sure to include the domain name here because Common Name is not so commonly honoured by itself
DNS.3 = *.$NAME # Optionally, add additional domains (I've added a subdomain here)
IP.1 = 127.0.0.1
EOF
# Create the signed certificate
openssl x509 -req -in ./domain/$NAME.csr -CA ./ca/ca.crt -CAkey ./ca/ca.key -CAcreateserial \
-out ./domain/$NAME.crt -days 3650 -sha256 -extfile ./domain/$NAME.ext

cat ./domain/$NAME.crt ./domain/$NAME.key > ./domain/$NAME.pem

openssl x509 -in ./domain/$NAME.crt -out ./domain/$NAME.cer -outform PEM

openssl x509 -noout -text -in ./domain/$NAME.crt